# Coin Rush Adventure — Ready-to-build package

This package contains:
- `web/index.html`: complete playable HTML5 game.
- `android/`: Android Studio WebView wrapper that loads the same game offline.
- No remote game assets or CDN dependencies are required.

## Test immediately
Open `web/index.html` in Chrome/Edge on desktop or Android.

## Build Android
1. Install Android Studio with Android SDK Platform 36.
2. Open the `android` folder in Android Studio.
3. Let Gradle sync.
4. Run on a real Android phone/emulator.
5. For Google Play, create a signed Android App Bundle (.aab).
6. Keep your upload/signing key safe.

## Important
This package is ready to build, but I cannot sign it with your private Play App Signing/upload key or upload it to your Play Console for you.

Google Play requires a signed AAB and your own developer-account/store declarations.
As of August 11, 2026, new apps submitted from August 31, 2026 must target Android 16/API 36 or higher.

The current game is offline and stores scores/settings locally. It does not request internet, location, contacts, camera, microphone, or advertising permissions.
